name(smtlib).
title('SMT-LIB parser for SWI-Prolog').
version('0.0.1').
author('José Antonio Riaza Valverde', 'riaza.valverde@gmail.com').
maintainer('José Antonio Riaza Valverde', 'riaza.valverde@gmail.com').
packager('José Antonio Riaza Valverde', 'riaza.valverde@gmail.com').
home('https://github.com/jariazavalverde/prolog-smtlib').
download('https://github.com/jariazavalverde/prolog-smtlib').